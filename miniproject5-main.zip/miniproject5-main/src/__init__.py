"""House Price Prediction System package."""
__version__ = "2.0.0"
